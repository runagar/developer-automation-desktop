---
name: create-jira-issue
description: Create a new Jira issue through the globally installed jira-tools CLI when the user explicitly asks to create an issue. Preview and obtain approval before submission.
allowed-tools: shell, read, edit
---

# Create a Jira issue

1. Confirm the intended project, issue type, summary, and description from the user's request. Never infer permission to create from a planning or specification task.
2. Read relevant existing issues through `jira-access`: vault first, missing issues fetched into context only.
3. Run `jira-tools issue fields --project <PROJECT> --type <TYPE> --json` to inspect the available fields and required options. Only projects in the user-level write allowlist can be submitted. Do not broaden that allowlist to bypass a rejection.
4. Save a draft JSON file under the current project's `tmp/`, preserving existing user-owned files. The shape is:

   ```json
   {
     "project": "PROJECT",
     "issueType": "Task",
     "summary": "Imperative issue summary",
     "description": "*Context*\nJira wiki markup, not Markdown.",
     "fields": {}
   }
   ```

   Additional create-screen fields, such as labels, components, or required custom fields, go in `fields`. Use IDs/options from metadata. Never use a converted vault note as a write payload or silently upload unresolved ambiguities from a specification.
5. Run `jira-tools issue create --file <draft.json> --dry-run --json`. This validates with read-only metadata requests and does not create anything.
6. Show the user the exact target project and issue type, summary, description, and additional fields. Obtain explicit approval of that payload before submission. A previous request to investigate or prepare is not approval to submit.
7. Submit once using `jira-tools issue create --file <draft.json> --submit --json` only after approval. If the draft changes after approval, preview it and obtain approval again.
8. Report the returned key and URL. Never write the result to the vault; DAD alone owns vault population.
9. Never blindly retry creation. Exit code 8 / `UNKNOWN_OUTCOME` means the issue may already exist; ask the user to verify in Jira before another attempt. The tool does not guarantee exactly-once creation.

Never print a PAT, inspect credential files, pass tokens in command arguments, or use an arbitrary REST command to bypass validation. No real test issues should be created without explicit user approval.
