---
name: jira-access
description: Read Jira issues from the local vault or fetch missing issues into agent context using the globally installed jira-tools CLI. Use for Jira access and authentication troubleshooting.
allowed-tools: shell, read
---

# Jira access

1. Always first read `~/.config/vault/jira/<PROJECT>/<KEY>.md` using the issue-key prefix as the project.
2. If the note is missing, run `jira-tools issue fetch <KEY> --json` from the current project. Use the `data` in its successful JSON response directly in context. Fetch individually referenced missing issues only when needed.
3. Never save a fetched issue to the vault or any other issue cache. Only DAD writes or refreshes vault notes. Do not invoke DAD source files, IPC, or a command from inside its checkout.
4. If a vault note exists, use it. Fetching a newer copy requires an explicit user request, and the result still stays in context only.
5. On configuration failures, `jira-tools auth status --json` reports configuration sources without revealing the PAT. `--check` makes a read-only authenticated identity request. Never read or print credential files or pass a PAT in arguments.
6. If the CLI is unavailable or authentication fails, explain the problem and ask the user to configure it. Never install an unrelated `jira` binary or fall back to inspecting secrets.
7. Fetching is not permission to change Jira. Use the `create-jira-issue` skill for explicitly requested creation. Specification and planning tasks remain non-mutating.

All commands work from any project. No MCP connection or running DAD instance is required. There are no vault-writing CLI commands.
