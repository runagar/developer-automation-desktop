# Jira Tools

Standalone Jira Data Center REST library and `jira-tools` CLI. DAD uses the library; agents use the CLI from any working directory. There is no Electron dependency, daemon, MCP requirement, project-local configuration, or runtime dependency on either checkout.

**Only DAD writes the Jira vault.** This package has no vault-writing or issue-caching code. Agents read existing notes directly and fetch missing issues into their context only. DAD retains graph traversal, refresh/freshness policies, Markdown-note persistence, UI and session integration.

## Develop and distribute

Requires Node.js 20.18+ (including DAD's Electron runtime).

```sh
npm ci
npm test
npm run typecheck
mkdir -p releases
npm pack --pack-destination releases
npm install --global --prefix "$HOME/.local" ./releases/rulu-jira-tools-0.1.0.tgz
```

Ensure `~/.local/bin` is on PATH in agent shells. The installed package is a copy, not a symlink to this repository. Do not use `npm link` or an absolute checkout launcher. DAD vendors the identical tarball and pins its integrity in package-lock.json; no registry publication is needed. The package is private to prevent accidental public publication. For a release, bump the version, rerun tests, pack once, and update both installations with that same artifact.

The binary deliberately is not named `jira`, which may already refer to an unrelated MCP server.

## Authentication

The default user-level store is `~/.config/jira-tools/`, or `$XDG_CONFIG_HOME/jira-tools/`:

- `config.json`: Base URL and `writeProjects` allowlist. An empty allowlist denies all creation.
- `credentials.env`: PAT plus its bound Base URL, mode `0600`. The binding fails closed if configuration and credential files disagree during an update. The directory is created with mode `0700`.

`ATLASSIAN_PAT` and `ATLASSIAN_BASE_URL` override the file values. Project `.env` files are never read. Keep secrets out of command arguments and shell tracing.

One-time import from an existing DAD **data directory**, not its source repository:

```sh
jira-tools auth migrate-dad --from "$HOME/.config/dad/dad" --json
```

This copies only the Atlassian pair, never Nykredit username/password, and never overwrites existing shared settings. The legacy file is retained for rollback. Supply `--write-projects KEY,KEY` when initializing an approved write allowlist. DAD performs the same non-overwriting import on first startup after upgrading. Its Jira settings UI then edits the shared store; Nykredit login remains DAD-local. Credentials are reread on each operation, so rotations are visible without a process-lifetime PAT cache.

For standalone setup, pipe a PAT from an approved secret manager to `jira-tools auth configure --base-url https://jira.example.com --pat-stdin`, optionally with `--write-projects KEY,KEY`. Do not put the PAT itself in the command. Manage the non-secret write allowlist in user-level `config.json`; agent instructions prohibit broadening it to evade a denial.

```sh
jira-tools auth status --json
jira-tools auth status --check --json
```

Status never reveals the PAT. The first command is local; `--check` makes an authenticated GET to `myself`. HTTPS certificate verification stays enabled, authenticated redirects are not followed, and requests time out after 30 seconds. A crashed settings update can leave `.settings.lock`; verify that no writer is running before removing that specific lock. A mismatched credential binding must be repaired by saving the URL and PAT together.

## Read an issue

Read `~/.config/vault/jira/<PROJECT>/<KEY>.md` first. Only if it is missing, or the user explicitly requests a fresh copy:

```sh
jira-tools issue fetch PROJECT-123 --json
```

The response contains the same schema-version-4 issue shape used by DAD, with its description converted to Markdown. It goes to stdout only. There are no automatic graph fetches, note writes, freshness updates, or issue caches.

## Create an issue

Jira Data Center 8.4+ project/type-specific paginated metadata endpoints are used; the deprecated unbounded `createmeta` endpoint is not used.

```sh
jira-tools issue fields --project PROJECT --type Task --json
jira-tools issue create --file ./tmp/draft.json --dry-run --json
jira-tools issue create --file ./tmp/draft.json --submit --json
```

Draft shape:

```json
{
  "project": "PROJECT",
  "issueType": "Task",
  "summary": "Describe the intended change",
  "description": "*Context*\nNative Jira wiki markup.",
  "fields": {
    "labels": ["example"]
  }
}
```

Issue type accepts an ID or unambiguous name. Additional fields use create-screen field IDs and Jira-native values. Required fields, basic schema types, and advertised allowed options are validated. Jira remains authoritative for workflow/plugin constraints. `--dry-run` may GET metadata, but never POSTs; `--submit` revalidates the draft before sending it. Get human approval of the preview before submitting. Read models and converted vault Markdown are deliberately not write payloads. Creation does not populate the vault.

JSON output is `{ "ok": true, "data": ... }` or `{ "ok": false, "error": { "code": ..., "message": ..., "fields": ... } }`. Diagnostics do not contaminate stdout. Exit codes: `0` success, `1` API failure, `2` configuration/validation, `3` authentication, `4` permission/allowlist, `5` not found, `6` rate limit, `7` transport, `8` unknown creation outcome. There are no automatic retries. If creation times out, returns a server error, or loses its receipt, verify in Jira before retrying; exactly-once creation is not guaranteed.

## Agents

Install the included `jira-access` and `create-jira-issue` skills in the user's shared skill directory. Existing plan/specify workflows remain non-mutating and should use the read-only CLI fallback for missing vault notes. Do not grant the CLI vault-write commands or ask it to populate DAD.

DAD's existing terminal-key autodetection may independently populate a printed key when enabled. That remains DAD-owned behavior and is not changed by this extraction.

## Library

```ts
import { JiraClient } from '@rulu/jira-tools';

const client = new JiraClient();
const issue = await client.fetchIssue('PROJECT-123');
```

Credentials, fetch, timeout, and allowed write projects can be injected for tests. The default client uses only the user-level store/environment. The library never logs credentials or writes issue data.
